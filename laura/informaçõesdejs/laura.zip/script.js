const greetingMenssage = () => 
 let  = new Date(). getHours();
 if (h <=5) return 'Boa madrugada';
 if (h< 12) return 'Bom diaa';
 if (h<18) return 'Boa tarde';
  return 'Boa noite';

document.getElementById("mensagem").innerHTML =(greetingMenssage());